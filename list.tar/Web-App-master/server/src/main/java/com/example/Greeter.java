package com.example;

/**
 * This is a sample class.
 */
public class Greeter {

  /**
   * This is a constructor
   */
  public Greeter() {

  }

  //TODO: Add javadoc comment
  public String greet(String someone) {
    return String.format("Hello, %s!", someone);
  }
  //checking commit-msg hook
  public void test(){
	  System.out.println("Edit by Deepak");
  }
}
